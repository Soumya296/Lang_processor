for(a=10,b=50;a<50 || b > 10;a++,b*=2)
{
	a = 5;
	a = b+c-5;
	if(a<50 && b>10) 
	{a++;}
	else {
		if(a>10)
		{
			a--;
		}
		c++;
		a = b+c-55;
		if(a>=5) {continue;}
		}
	b++;
}

